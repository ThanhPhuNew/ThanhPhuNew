import json
from queue import Queue
from datetime import datetime, timedelta
import time
import os
import sys
import random
import re, unicodedata
from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES, ADMIN
from zlapi.models import *
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from xbzl import CommandHandler
from zlapi import ZaloAPI
from colorama import Fore, Style, init
from logging_utils import Logging
from datetime import datetime
import threading
import requests
from requests.adapters import HTTPAdapter

import pyfiglet


from requests.packages.urllib3.util.retry import Retry
import os

logger = Logging()

colors1 = [
    "FF9900", "FFFF33", "33FFFF", "FF99FF", "FF3366", "FFFF66", "FF00FF", "66FF99", "00CCFF", 
    "FF0099", "FF0066", "0033FF", "FF9999", "00FF66", "00FFFF", "CCFFFF", "8F00FF", "FF00CC", 
    "FF0000", "FF1100", "FF3300", "FF4400", "FF5500", "FF6600", "FF7700", "FF8800", "FF9900", 
    "FFaa00", "FFbb00", "FFcc00", "FFdd00", "FFee00", "FFff00", "FFFFFF", "FFEBCD", "F5F5DC", 
    "F0FFF0", "F5FFFA", "F0FFFF", "F0F8FF", "FFF5EE", "F5F5F5"
]

text = "Thanh Phu"
xb = pyfiglet.figlet_format(text)
print(xb)

class ResetBot:
    def __init__(self, reset_interval=3600):
        self.reset_event = threading.Event()
        self.reset_interval = reset_interval
        threading.Thread(target=self.reset_code_periodically, daemon=True).start()

    def reset_code_periodically(self):
        while not self.reset_event.is_set():
            time.sleep(self.reset_interval)
            logger.restart("Restart")
            self.restart_bot()

    def restart_bot(self):
        try:
            current_time = datetime.now().strftime("%H:%M:%S")
            gui_message = f"Bot khởi động lại thành công vào lúc: {current_time}"
            logger.restart(gui_message)
            python = sys.executable
            os.execl(python, python, *sys.argv)
        except Exception as e:
            logger.error(f"Lỗi khi khởi động lại bot: {e}")

def initialize_group_info(bot, allowed_thread_ids):
    for thread_id in allowed_thread_ids:
        group_info = bot.fetchGroupInfo(thread_id).gridInfoMap.get(thread_id, None)
        if group_info:
            bot.group_info_cache[thread_id] = {
                "name": group_info.get('name', 'N/A'),
                "member_list": group_info.get('memVerList', []),
                "total_member": group_info.get('totalMember', 0)
            }
        else:
            print(f"Bỏ qua nhóm {thread_id}")

def check_member_changes(bot, thread_id):
    current_group_info = bot.fetchGroupInfo(thread_id).gridInfoMap.get(thread_id, None)
    cached_group_info = bot.group_info_cache.get(thread_id, None)

    if not cached_group_info or not current_group_info:
        return [], []  

    old_members = set([member.split('_')[0] for member in cached_group_info["member_list"]])
    new_members = set([member.split('_')[0] for member in current_group_info['memVerList']])
    
    joined_members = new_members - old_members
    left_members = old_members - new_members

    bot.group_info_cache[thread_id] = {
        "name": current_group_info.get('name', 'N/A'),
        "member_list": current_group_info.get('memVerList', []),
        "total_member": current_group_info.get('totalMember', 0)
    }

    return joined_members, left_members
def handle_group_member(bot, message_object, author_id, thread_id, thread_type):
    joined_members, left_members = check_member_changes(bot, thread_id)

    if joined_members:
        for member_id in joined_members:
            member_info = bot.fetchUserInfo(member_id).changed_profiles.get(member_id, {})
            member_name = member_info.get('displayName', 'Người dùng ẩn danh')
            cover = member_info.get('avatar', None)

            welcome_message = f"[PROJECT NOTIFICATION GROUP ]\n> Chào mừng: {member_name}\n> Bạn là thành viên thứ: {bot.group_info_cache[thread_id]['total_member']}\n> Đã tham gia nhóm: {bot.group_info_cache[thread_id]['name']}."

            color_styles = []
            start_idx = 0
            colors = random.sample(colors1, k=min(len(colors1), 3))

            for color in colors:
                length = len(welcome_message) // len(colors)
                color_style = MessageStyle(
                    style="color",
                    color=color,
                    offset=start_idx,
                    length=length,
                    auto_format=False
                )
                color_styles.append(color_style)
                start_idx += length

            font_style = MessageStyle(
                style="font",
                size="13",
                offset=0,
                length=len(welcome_message),
                auto_format=False
            )
            multi_style = MultiMsgStyle(color_styles + [font_style])

            bot.send(Message(text=welcome_message, style=multi_style), thread_id, thread_type)

            tagged_users = ""

            bot.kickUsersInGroup( tagged_users, thread_id)

    if left_members:
        for member_id in left_members:
            member_info = bot.fetchUserInfo(member_id).changed_profiles.get(member_id, {})
            member_name = member_info.get('displayName', 'Người dùng ẩn danh')
            cover = member_info.get('avatar', None)
            timejoin = datetime.now().strftime("%H:%M:%S")

            farewell_message = f"[PROJECT NOTIFICATION GROUP ]\n> Người dùng: {member_name}\n> Đã rời nhóm\n> {bot.group_info_cache[thread_id]['name']}\n> Vào lúc: {timejoin}\n> Tổng thành viên còn lại: {bot.group_info_cache[thread_id]['total_member']}."

            color_styles = []
            start_idx = 0
            colors = random.sample(colors1, k=min(len(colors1), 3))

            for color in colors:
                length = len(farewell_message) // len(colors)
                color_style = MessageStyle(
                    style="color",
                    color=color,
                    offset=start_idx,
                    length=length,
                    auto_format=False
                )
                color_styles.append(color_style)
                start_idx += length

            font_style = MessageStyle(
                style="font",
                size="13",
                offset=0,
                length=len(farewell_message),
                auto_format=False
            )
            multi_style = MultiMsgStyle(color_styles + [font_style])

            bot.send(Message(text=farewell_message, style=multi_style), thread_id, thread_type)

            idmem = ""

            client.addUsersToGroup(idmem, thread_id)

init(autoreset=True)

colors = [
    "FF9900", "FFFF33", "33FFFF", "FF99FF", "FF3366", 
    "FFFF66", "FF00FF", "66FF99", "00CCFF", "FF0099", 
    "FF0066", "0033FF", "FF9999", "00FF66", "00FFFF", 
    "CCFFFF", "8F00FF", "FF00CC", "FF0000", "FF1100", 
    "FF3300"
]

def hex_to_ansi(hex_color):
    hex_color = hex_color.lstrip('#')
    r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    return f'\033[38;2;{r};{g};{b}m'

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies, reset_interval=3600):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.command_handler = CommandHandler(self)
        self.reset_bot = ResetBot(reset_interval)
        self.group_info_cache = {}
        self.session = requests.Session()
        self.message_queue = Queue()
        self.processed_messages = set()
        self.response_time_limit = timedelta(seconds=70)  
        self.is_mute_list = {}

        self.last_sms_times = {}
        retry_strategy = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)





        all_group = self.fetchAllGroups()
        
        allowed_thread_ids = list(all_group.gridVerMap.keys())
        initialize_group_info(self, allowed_thread_ids)
        self.start_member_check_thread(allowed_thread_ids)

    def start_member_check_thread(self, allowed_thread_ids):
        def check_members_loop():
            while True:
                try:
                    for thread_id in allowed_thread_ids:
                        handle_group_member(self, None, None, thread_id, ThreadType.GROUP)
                    time.sleep(0.5)
                except Exception as e:
                    logger.error(f"Error in member check loop: {e}")
                    time.sleep(5)

        thread = threading.Thread(target=check_members_loop)
        thread.daemon = True
        thread.start()

    def send_request(self, url):
        try:
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Lỗi request: {e}")
            return None

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        try:
            message_text = message.text if isinstance(message, Message) else str(message)
            author_info = self.fetchUserInfo(author_id).changed_profiles.get(author_id, {})
            author_name = author_info.get('zaloName', 'đéo xác định')

            group_info = self.fetchGroupInfo(thread_id)
            group_name = group_info.gridInfoMap.get(thread_id, {}).get('name', 'N/A')

            current_time = time.strftime("%H:%M:%S - %d/%m/%Y", time.localtime())

            colors_selected = random.sample(colors, 8)
            print(f"{hex_to_ansi(colors_selected[0])}{Style.BRIGHT}------------------------------{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[1])}{Style.BRIGHT}- Message: {message_text}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[2])}{Style.BRIGHT}- ID NGƯỜI DÙNG: {author_id}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[6])}{Style.BRIGHT}- TÊN NGƯỜI DÙNG: {author_name}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[3])}{Style.BRIGHT}- ID NHÓM: {thread_id}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[4])}{Style.BRIGHT}- TÊN NHÓM: {group_name}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[5])}{Style.BRIGHT}- TYPE: {thread_type}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[7])}{Style.BRIGHT}- THỜI GIAN NHẬN ĐƯỢC: {current_time}{Style.RESET_ALL}")
            print(f"{hex_to_ansi(colors_selected[0])}{Style.BRIGHT}------------------------------{Style.RESET_ALL}")
            

            if isinstance(message, str):
                self.command_handler.handle_command(message, author_id, message_object, thread_id, thread_type)
                if self.is_mute_list.get(thread_id):
                   if author_id in self.is_mute_list[thread_id]:
                    self.deleteGroupMsg(message_object.msgId, message_object.uidFrom, message_object.cliMsgId, thread_id)
        except Exception as e:
         logger.error(f"Lỗi xử lý tin nhắn: {e}")

if __name__ == "__main__":
    try:
        client = Client(API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES)
        client.listen(thread=True)
    except Exception as e:
        logger.error(f"Lỗi khởi tạo client: {e}")
        time.sleep(10)