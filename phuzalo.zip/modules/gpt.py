from zlapi.models import Message
import requests
import urllib.parse

des = {
    'version': "2.0.0",
    'credits': "Nguyễn Đức Tài", 
    'description': "chat gpt-4o" # Xuân Bách fix
}

def handle_gpt_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split()

    if len(text) < 2:
        client.sendMessage(Message(text="Vui lòng nhập câu hỏi để trò chuyện cùng GPT."), thread_id, thread_type)
        return

    content = " ".join(text[1:])
    cau_hoi = urllib.parse.quote(content, safe='')

    try:
        response = requests.get(f'https://api.sumiproject.net/gpt4?q={cau_hoi}')
        response.raise_for_status()
        ai_data = response.json()

        if isinstance(ai_data, dict):
            data = ai_data.get('data', {})
            gui = data if isinstance(data, str) else data.get('response', 'Không có phản hồi từ GPT.')
        else:
            gui = 'Phản hồi từ API không phải là JSON hợp lệ.'

        client.sendMessage(Message(text=gui), thread_id, thread_type)

    except requests.exceptions.RequestException as e:
        client.sendMessage(Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}"), thread_id, thread_type)
    except (ValueError, KeyError) as e:
        client.sendMessage(Message(text=f"Lỗi phản hồi từ API: {str(e)}"), thread_id, thread_type)
    except Exception as e:
        client.sendMessage(Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}"), thread_id, thread_type)

def get_xbzl():
    return {
        'gpt': handle_gpt_command
    }
